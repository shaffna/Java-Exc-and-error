package javaExceptionsandErrorHandling;

import java.util.ArrayList;

public class ArrayList2 {

	public static void main(String[] args) {
		methodForArraylist();
	}
		public static void methodForArraylist() {
		 ArrayList<String> list = new ArrayList<>();
		 
	        list.add("Cat");
	        list.add("Dog");
	        list.add("Cow");

	        System.out.println("ArrayList before clearing: " + list);
	        list.clear();
	        System.out.println("ArrayList after clearing: " + list);

	


		
	}

}
