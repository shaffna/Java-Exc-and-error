package javaExceptionsandErrorHandling;

import java.util.TreeMap;

public class TreeMap3 {

	public static void main(String[] args) {
	
		        TreeMap<Integer, String> employeeMap = new TreeMap<>();
		        employeeMap.put(11, "Mushtaq");
		        employeeMap.put(16, "Shaffna");
		        employeeMap.put(13, "Hiba");
		        employeeMap.put(19, "Arun");

		        System.out.println("Employees in alphabetical order:");
		        employeeMap.values().stream().sorted().forEach(System.out::println);
		    }
		


	

}
