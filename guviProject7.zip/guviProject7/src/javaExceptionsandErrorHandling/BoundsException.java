package javaExceptionsandErrorHandling;

public class BoundsException {

	public static void main(String[] args) {
		try {
			int[] num = {2,3,4,5,6};
			System.out.println(num[10]);
		}
		catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Error: Accessing an index outside the array bounds.");
		}
			
		try {
			String name = "shaffna";
			System.out.println(name.charAt (10));
		}
		catch (StringIndexOutOfBoundsException e) {
            System.out.println("Error: Accessing an index outside the String bounds.");
		}
			
		

	}

}
